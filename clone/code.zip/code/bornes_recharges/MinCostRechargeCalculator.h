#include <vector>

// Nom(s) étudiant(s) / Name(s) of student(s):

// ce fichier contient les declarations des methodes de la classe MaxToysCalculator
// peut être modifié si vous voulez ajouter d'autres méthodes à la classe
// this file contains the declarations of the methods of the MaxToysCalculator class
// can be modified if you wish to add other methods to the class

class MinCostRechargeCalculator{
    public :
    MinCostRechargeCalculator();
        int CalculateMinCostRecharge(const std::vector<int>& arr);
};